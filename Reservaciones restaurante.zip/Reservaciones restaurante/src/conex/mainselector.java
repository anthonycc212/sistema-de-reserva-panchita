/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conex;

/**
 *
 * @author USER
 */

import vista.SelectorRol;

public class mainselector {
    public static void main(String[] args) {
        // Este es el punto de entrada de la aplicación
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SelectorRol().setVisible(true); // Abre el selector de rol
            }
        });
    }
}
